<?php
define('MYSQL_HOST','62.149.150.196');
define('MYSQL_USER','Sql690670');
define('MYSQL_PASSWORD','c03ea19d');
define('MYSQL_DB','Sql690670_4');
?>

