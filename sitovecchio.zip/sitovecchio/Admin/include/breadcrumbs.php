<li><a href="home.php">Home</a></li>
<li>www.sekurbox.com</li>