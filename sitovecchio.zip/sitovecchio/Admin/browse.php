<?php include 'browse_func.php'; ?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
  </head>
   <body>
    <ul>
      <?php Elenca(); ?>
    </ul>
    </body>
</html