<?php

include './include/auth.inc.php';
require './include/db.inc.php';

$db = mysql_connect(MYSQL_HOST, MYSQL_USER, MYSQL_PASSWORD) or
	die('unable to connect. Check your connection parameters.');
mysql_select_db(MYSQL_DB, $db) or die(mysql_error($db));

$query="UPDATE slider SET img".$_POST['variabile']."='' WHERE id=1";
mysql_query($query);



?>